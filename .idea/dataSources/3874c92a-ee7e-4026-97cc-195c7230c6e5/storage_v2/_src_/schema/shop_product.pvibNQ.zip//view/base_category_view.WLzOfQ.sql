create view base_category_view as
select `shop_product`.`base_category3`.`id`   AS `id`,
       `shop_product`.`base_category1`.`id`   AS `category1_id`,
       `shop_product`.`base_category1`.`name` AS `category1_name`,
       `shop_product`.`base_category2`.`id`   AS `category2_id`,
       `shop_product`.`base_category2`.`name` AS `category2_name`,
       `shop_product`.`base_category3`.`id`   AS `category3_id`,
       `shop_product`.`base_category3`.`name` AS `category3_name`
from ((`shop_product`.`base_category1` join `shop_product`.`base_category2` on ((`shop_product`.`base_category1`.`id` =
                                                                                 `shop_product`.`base_category2`.`category1_id`)))
       join `shop_product`.`base_category3`
            on ((`shop_product`.`base_category2`.`id` = `shop_product`.`base_category3`.`category2_id`)));

